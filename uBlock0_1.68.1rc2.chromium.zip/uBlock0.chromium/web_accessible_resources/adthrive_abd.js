(( ) => {
    const d = new Date(Date.now() + 30000);
    document.cookie = `__adblocker=false; expires=${d.toUTCString()}; path=/`;
})();
